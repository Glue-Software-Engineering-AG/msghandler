A sample eSchKG (native) inbox
