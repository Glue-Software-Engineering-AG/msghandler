In this sample directory the MH internal DB will be placed
