In this directory, MH will prepare messages for sending
