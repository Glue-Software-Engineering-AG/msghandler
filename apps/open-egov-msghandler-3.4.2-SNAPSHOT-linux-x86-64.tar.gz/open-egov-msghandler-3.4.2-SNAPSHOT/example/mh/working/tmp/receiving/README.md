In this directory MH will temporarly place received messages.
