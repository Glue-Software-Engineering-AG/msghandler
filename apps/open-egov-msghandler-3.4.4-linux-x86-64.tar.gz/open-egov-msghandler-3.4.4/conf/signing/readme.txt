MessageHandler
--------------

Demo files for the "NativeApp PDF Signing".

Password for the file "demo-certificate.p12" is: 123456



