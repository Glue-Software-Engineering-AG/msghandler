A sample eSchKG (native) outbox
