A sample directory for corrupted messages
